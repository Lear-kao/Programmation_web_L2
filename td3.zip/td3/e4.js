let texte = document.getElementById("texte");

function b_1()
{
    texte.textContent = "Il fait mauvais"
}

function b_2()
{
    texte.textContent = "Il fait beau"
}

function b_3()
{
    let a =  "white";
    texte.style.color = a;
}

